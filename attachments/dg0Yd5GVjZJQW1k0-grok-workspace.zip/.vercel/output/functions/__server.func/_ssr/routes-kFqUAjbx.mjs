import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Cell, i as Bar, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-kFqUAjbx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Trade terisi Mesin 2, agregat Excel 27 Okt 2026.
* n dan total R adalah angka monitor, bukan trade fiktif per koin.
*/
var COHORT = [
	{
		id: "dd-rsi",
		label: "Double Deviation, tekanan beli melemah, RSI divergence",
		side: "SHORT",
		tags: ["dd", "rsi-div"],
		n: 1,
		wins: 0,
		totalR: -1
	},
	{
		id: "fib-rsi-trend",
		label: "Fib 0.75 tren turun, RSI divergence, searah tren",
		side: "SHORT",
		tags: [
			"fib75",
			"rsi-div",
			"with-trend"
		],
		n: 1,
		wins: 1,
		totalR: 2
	},
	{
		id: "fib-trend",
		label: "Fib 0.75 tren turun, searah tren",
		side: "SHORT",
		tags: ["fib75", "with-trend"],
		n: 6,
		wins: 3,
		totalR: 3
	},
	{
		id: "wolf-bull-trend",
		label: "Wolf bullish, searah tren",
		side: "LONG",
		tags: ["wolf", "with-trend"],
		n: 1,
		wins: 1,
		totalR: 2
	},
	{
		id: "wolf-bull",
		label: "Wolf bullish tanpa konfluensi",
		side: "LONG",
		tags: ["wolf"],
		n: 2,
		wins: 0,
		totalR: -2
	},
	{
		id: "wolf-fail",
		label: "Wolf: breakout trendline gagal",
		side: "SHORT",
		tags: ["wolf"],
		n: 1,
		wins: 0,
		totalR: -1
	},
	{
		id: "bo-trend",
		label: "Breakout ber-close, retest, searah tren",
		side: "LONG",
		tags: ["breakout", "with-trend"],
		n: 1,
		wins: 0,
		totalR: -1
	},
	{
		id: "dev-fib",
		label: "Deviasi atas gagal, Fib 0.75 turun, RSI, searah tren",
		side: "SHORT",
		tags: [
			"dev-high",
			"fib75",
			"rsi-div",
			"with-trend"
		],
		n: 1,
		wins: 1,
		totalR: 2
	},
	{
		id: "dev-rsi",
		label: "Deviasi atas gagal, RSI divergence",
		side: "SHORT",
		tags: ["dev-high", "rsi-div"],
		n: 1,
		wins: 1,
		totalR: 2
	},
	{
		id: "dev-mon-fib",
		label: "Deviasi atas + Monday High + Fib turun + RSI + tren",
		side: "SHORT",
		tags: [
			"dev-high",
			"monday-high",
			"fib75",
			"rsi-div",
			"with-trend"
		],
		n: 1,
		wins: 0,
		totalR: -1
	},
	{
		id: "dev-bare",
		label: "Deviasi atas gagal bertahan",
		side: "SHORT",
		tags: ["dev-high"],
		n: 1,
		wins: 1,
		totalR: 2
	},
	{
		id: "dev-low",
		label: "Deviasi bawah lalu recovery",
		side: "LONG",
		tags: ["dev-low"],
		n: 1,
		wins: 0,
		totalR: -1
	},
	{
		id: "mh-rsi-trend",
		label: "Monday High reclaim, RSI divergence, searah tren",
		side: "SHORT",
		tags: [
			"monday-high",
			"rsi-div",
			"with-trend"
		],
		n: 1,
		wins: 1,
		totalR: 2
	},
	{
		id: "mh-wolf",
		label: "Monday High reclaim + Wolf gagal",
		side: "SHORT",
		tags: ["monday-high", "wolf"],
		n: 1,
		wins: 1,
		totalR: 2
	},
	{
		id: "mh-trend",
		label: "Monday High reclaim, searah tren",
		side: "SHORT",
		tags: ["monday-high", "with-trend"],
		n: 2,
		wins: 2,
		totalR: 4
	},
	{
		id: "mh-bare",
		label: "Monday High reclaim",
		side: "SHORT",
		tags: ["monday-high"],
		n: 3,
		wins: 1,
		totalR: 0
	},
	{
		id: "ml-obv-trend",
		label: "Monday Low reclaim, OBV divergence, searah tren",
		side: "LONG",
		tags: [
			"monday-low",
			"obv-div",
			"with-trend"
		],
		n: 2,
		wins: 1,
		totalR: 1
	},
	{
		id: "ml-obv",
		label: "Monday Low reclaim, OBV divergence",
		side: "LONG",
		tags: ["monday-low", "obv-div"],
		n: 2,
		wins: 0,
		totalR: -2
	},
	{
		id: "ml-rsi",
		label: "Monday Low reclaim, RSI divergence",
		side: "LONG",
		tags: ["monday-low", "rsi-div"],
		n: 1,
		wins: 0,
		totalR: -1
	},
	{
		id: "ml-wolf-trend",
		label: "Monday Low reclaim, Wolf bullish, searah tren",
		side: "LONG",
		tags: [
			"monday-low",
			"wolf",
			"with-trend"
		],
		n: 2,
		wins: 0,
		totalR: -2
	},
	{
		id: "ml-trend",
		label: "Monday Low reclaim, searah tren",
		side: "LONG",
		tags: ["monday-low", "with-trend"],
		n: 1,
		wins: 0,
		totalR: -1
	},
	{
		id: "ml-bare",
		label: "Monday Low reclaim",
		side: "LONG",
		tags: ["monday-low"],
		n: 28,
		wins: 0,
		totalR: -28
	}
];
var DAILY = [
	{
		day: "15",
		r: -13
	},
	{
		day: "17",
		r: 2
	},
	{
		day: "18",
		r: 1
	},
	{
		day: "19",
		r: -7
	},
	{
		day: "20",
		r: 1
	},
	{
		day: "21",
		r: -2
	},
	{
		day: "22",
		r: 3
	},
	{
		day: "23",
		r: -2
	},
	{
		day: "24",
		r: -1
	},
	{
		day: "26",
		r: -1
	}
];
var LEGACY = {
	published: 228,
	triggered: 79,
	tp: 14,
	sl: 47,
	expired: 125,
	pending: 42,
	expectancy: -.31,
	totalR: -19
};
/** Aturan Mesin 2 v2.0.0 — dikunci sebelum angka ulang dipakai sebagai bukti. */
var RULES = {
	version: "m2-2.1.0",
	minRr: 1.5,
	minSlPct: .6,
	maxSlPct: 8,
	minDistPct: .15,
	maxDistPct: 2.5,
	maxSameDirection: 3
};
var TAG_LABEL = {
	"monday-low": "Sweep Monday Low lalu reclaim",
	"monday-high": "Sweep Monday High lalu reclaim",
	fib75: "Fib 0.75",
	"with-trend": "searah tren",
	"rsi-div": "RSI divergence",
	"obv-div": "OBV divergence",
	"dev-high": "deviasi atas gagal bertahan",
	"dev-low": "deviasi bawah lalu recovery",
	wolf: "Wolf",
	breakout: "breakout / breakdown ber-close",
	dd: "Double Deviation"
};
function tagLabel(tag) {
	return TAG_LABEL[tag];
}
function hasConfluence(tags) {
	const core = tags.filter((t) => t !== "with-trend" && t !== "rsi-div" && t !== "obv-div");
	const div = tags.includes("rsi-div") || tags.includes("obv-div");
	const withTrend = tags.includes("with-trend");
	if (core.length >= 2) return true;
	if (core.length === 1 && (div || withTrend)) return true;
	return false;
}
function decide(input) {
	const symbol = input.symbol.trim().toUpperCase();
	if (!/^[A-Z0-9]{2,20}$/.test(symbol)) return {
		book: "REJECT",
		code: "MISSING_SYMBOL",
		note: "Simbol kosong atau tidak valid. Tidak masuk jurnal."
	};
	if (input.tpAlreadyTraded) return {
		book: "REJECT",
		code: "STALE_TP_ALREADY_TRADED",
		note: "TP sudah tercetak sebelum waktu keputusan. Bukan EXPIRED — setup tidak diterbitkan."
	};
	if (input.confirm === "bad") return {
		book: "REJECT",
		code: "INVALIDATED",
		note: "Close sudah menembus invalidation. Tidak diterbitkan."
	};
	if (input.rr < RULES.minRr) return {
		book: "REJECT",
		code: "RR_BELOW_MIN",
		note: `RR rencana ${input.rr.toFixed(2)} di bawah ${RULES.minRr} setelah biaya.`
	};
	if (input.slPct < RULES.minSlPct || input.slPct > RULES.maxSlPct) return {
		book: "REJECT",
		code: "SL_OUT_OF_BAND",
		note: `Jarak SL ${input.slPct.toFixed(1)}% di luar pita ${RULES.minSlPct}–${RULES.maxSlPct}%. Buku lebar tidak diskor.`
	};
	if (input.mode === "limit" && (input.distPct < RULES.minDistPct || input.distPct > RULES.maxDistPct)) return {
		book: "REJECT",
		code: "DISTANCE",
		note: "Limit di luar pita 0,15–2,5% dari harga keputusan, atau harga sudah mengejar level."
	};
	if (input.tags.includes("monday-low") && !input.tags.includes("with-trend")) return {
		book: "REJECT",
		code: "MONDAY_LOW_OFF",
		note: "Monday Low tanpa tren dimatikan. Oktober: 28 trade polos, 0 menang, −28 R."
	};
	if (input.tags.includes("monday-low") && input.tags.filter((t) => t !== "with-trend" && t !== "rsi-div" && t !== "obv-div").length < 2) return {
		book: "REJECT",
		code: "MONDAY_LOW_THIN",
		note: "Monday Low butuh dua struktur lain, bukan hanya divergensi. Pola ini yang merusak buku LONG."
	};
	if (input.tags.length === 1 && input.tags[0] === "wolf") return {
		book: "REJECT",
		code: "WOLF_BARE",
		note: "Wolf tanpa konfluensi lain dimatikan."
	};
	if (input.location === "mid" && !input.tags.includes("dd") && !input.tags.includes("dev-high") && !input.tags.includes("dev-low")) return {
		book: "WATCH",
		code: "MID_RANGE",
		note: "Harga di tengah range. Tidak ada setup — tunggu ekstrem."
	};
	if (input.confirm === "wait") return {
		book: "WATCH",
		code: "UNCONFIRMED",
		note: "Level menarik, belum ada close konfirmasi. Tidak bisa terisi."
	};
	if (input.side === "LONG" && input.btcBias < 0) return {
		book: "REJECT",
		code: "LONG_VS_BTC",
		note: "LONG ditolak saat bias harian BTC turun."
	};
	if (input.side === "SHORT" && input.btcBias > 0) return {
		book: "REJECT",
		code: "SHORT_VS_BTC",
		note: "SHORT ditolak saat bias harian BTC naik."
	};
	if (!hasConfluence(input.tags)) return {
		book: "WATCH",
		code: "NEEDS_CONFLUENCE",
		note: "Satu pemicu mentah. Tunggu konfluensi: searah tren, divergensi, atau struktur kedua."
	};
	if (input.sameDirectionToday >= RULES.maxSameDirection) return {
		book: "REJECT",
		code: "CORRELATION_CAP",
		note: `Sudah ${RULES.maxSameDirection} ${input.side} hari ini. Batch searah tidak menambah observasi.`
	};
	return {
		book: "ACTIONABLE",
		code: "PASS",
		note: `${input.side} konfluen, searah bias, TP belum basi, RR cukup. Bukan izin uang real.`
	};
}
/** Replay agregat Oktober: hanya filter yang terbaca dari alasan entry. */
function replayGroup(side, tags) {
	return decide({
		symbol: "REPLAY",
		side,
		tags,
		btcBias: 0,
		confirm: "ok",
		tpAlreadyTraded: false,
		mode: "market",
		distPct: 1,
		rr: 2,
		slPct: 3,
		location: "extreme",
		sameDirectionToday: 0
	});
}
/** Struktur tertutup untuk papan contoh. Bukan harga live dan bukan order. */
var SNAP = [
	{
		symbol: "SOL",
		px: 178.4,
		btcBias: 1,
		pos: .22,
		level: 176.2,
		side: "LONG",
		tags: [
			"fib75",
			"with-trend",
			"obv-div"
		],
		confirm: "ok",
		tpAlreadyTraded: false,
		atr: 4.2
	},
	{
		symbol: "ETH",
		px: 3240,
		btcBias: -1,
		pos: .78,
		level: 3288,
		side: "SHORT",
		tags: [
			"dev-high",
			"monday-high",
			"with-trend"
		],
		confirm: "ok",
		tpAlreadyTraded: false,
		atr: 62
	},
	{
		symbol: "BTC",
		px: 67420,
		btcBias: 0,
		pos: .51,
		level: 66800,
		side: "LONG",
		tags: ["fib75"],
		confirm: "wait",
		tpAlreadyTraded: false,
		atr: 900
	},
	{
		symbol: "AVAX",
		px: 28.4,
		btcBias: -1,
		pos: .18,
		level: 27.1,
		side: "LONG",
		tags: ["monday-low"],
		confirm: "ok",
		tpAlreadyTraded: false,
		atr: .7
	},
	{
		symbol: "LINK",
		px: 14.8,
		btcBias: 1,
		pos: .2,
		level: 14.55,
		side: "LONG",
		tags: ["dev-low", "with-trend"],
		confirm: "ok",
		tpAlreadyTraded: false,
		atr: .35
	},
	{
		symbol: "BNB",
		px: 612,
		btcBias: 1,
		pos: .84,
		level: 606,
		side: "SHORT",
		tags: ["wolf"],
		confirm: "ok",
		tpAlreadyTraded: false,
		atr: 9
	},
	{
		symbol: "ADA",
		px: .62,
		btcBias: -1,
		pos: .8,
		level: .64,
		side: "SHORT",
		tags: [
			"fib75",
			"rsi-div",
			"with-trend"
		],
		confirm: "wait",
		tpAlreadyTraded: false,
		atr: .018
	},
	{
		symbol: "TIA",
		px: 5.42,
		btcBias: -1,
		pos: .86,
		level: 5.55,
		side: "SHORT",
		tags: ["breakout", "with-trend"],
		confirm: "ok",
		tpAlreadyTraded: true,
		atr: .16
	},
	{
		symbol: "INJ",
		px: 22.1,
		btcBias: 1,
		pos: .24,
		level: 21.4,
		side: "LONG",
		tags: [
			"dd",
			"rsi-div",
			"with-trend"
		],
		confirm: "ok",
		tpAlreadyTraded: false,
		atr: .55
	},
	{
		symbol: "SUI",
		px: 2.18,
		btcBias: -1,
		pos: .73,
		level: 2.24,
		side: "SHORT",
		tags: ["monday-high", "with-trend"],
		confirm: "ok",
		tpAlreadyTraded: false,
		atr: .06
	}
];
function round(n) {
	if (n >= 100) return Math.round(n * 10) / 10;
	if (n >= 1) return Math.round(n * 100) / 100;
	return Math.round(n * 1e4) / 1e4;
}
function scanBoard() {
	const counts = {
		LONG: 0,
		SHORT: 0
	};
	const plans = [];
	for (const s of SNAP) {
		const level = s.level;
		const mode = (s.side === "LONG" ? s.px < level : s.px > level) ? "market" : "limit";
		const entry = mode === "market" ? s.px : level;
		const slDist = Math.max(s.atr * .8, entry * .01);
		const sl = s.side === "LONG" ? entry - slDist : entry + slDist;
		const risk = Math.abs(entry - sl);
		const tp = s.side === "LONG" ? entry + 2 * risk : entry - 2 * risk;
		const distPct = Math.abs(s.px - entry) / s.px * 100;
		const slPct = risk / entry * 100;
		const rr = risk > 0 ? Math.abs(tp - entry) / risk : 0;
		const location = s.pos > .35 && s.pos < .65 ? "mid" : "extreme";
		const verdict = decide({
			symbol: s.symbol,
			side: s.side,
			tags: s.tags,
			btcBias: s.btcBias,
			confirm: s.confirm,
			tpAlreadyTraded: s.tpAlreadyTraded,
			mode,
			distPct: mode === "market" ? 1 : distPct,
			rr,
			slPct,
			location,
			sameDirectionToday: counts[s.side]
		});
		if (verdict.book === "ACTIONABLE") counts[s.side] += 1;
		plans.push({
			symbol: s.symbol,
			side: s.side,
			entry: round(entry),
			sl: round(sl),
			tp: round(tp),
			mode,
			distPct,
			rr,
			slPct,
			tags: s.tags,
			verdict
		});
	}
	return plans;
}
function scoreCohort() {
	return COHORT.map((g) => {
		const v = replayGroup(g.side, g.tags);
		return {
			...g,
			book: v.book,
			code: v.code,
			note: v.note
		};
	});
}
function sumBook(rows, book) {
	const list = rows.filter((r) => r.book === book);
	const n = list.reduce((a, r) => a + r.n, 0);
	const wins = list.reduce((a, r) => a + r.wins, 0);
	const totalR = list.reduce((a, r) => a + r.totalR, 0);
	return {
		groups: list.length,
		n,
		wins,
		losses: n - wins,
		totalR,
		winRate: n ? wins / n : null,
		expectancy: n ? totalR / n : null
	};
}
var TAGS = [
	"monday-low",
	"monday-high",
	"fib75",
	"with-trend",
	"rsi-div",
	"obv-div",
	"dev-high",
	"dev-low",
	"wolf",
	"breakout",
	"dd"
];
var TABS = [
	{
		id: "ALL",
		label: "Semua grup"
	},
	{
		id: "ACTIONABLE",
		label: "Buku skor"
	},
	{
		id: "WATCH",
		label: "Watch"
	},
	{
		id: "REJECT",
		label: "Ditolak"
	}
];
function pct(n) {
	if (n == null) return "—";
	return `${(n * 100).toFixed(1)}%`;
}
function rtxt(n) {
	if (n == null) return "—";
	return `${n > 0 ? "+" : ""}${n.toFixed(2)} R`;
}
function Desk() {
	const rows = (0, import_react.useMemo)(() => scoreCohort(), []);
	const kept = sumBook(rows, "ACTIONABLE");
	const watch = sumBook(rows, "WATCH");
	const rejected = sumBook(rows, "REJECT");
	const [tab, setTab] = (0, import_react.useState)("ACTIONABLE");
	const visible = tab === "ALL" ? rows : rows.filter((r) => r.book === tab);
	const [symbol, setSymbol] = (0, import_react.useState)("SOL");
	const [side, setSide] = (0, import_react.useState)("SHORT");
	const [btcBias, setBtcBias] = (0, import_react.useState)(-1);
	const [confirm, setConfirm] = (0, import_react.useState)("ok");
	const [stale, setStale] = (0, import_react.useState)(false);
	const [mode, setMode] = (0, import_react.useState)("limit");
	const [dist, setDist] = (0, import_react.useState)(.8);
	const [rr, setRr] = (0, import_react.useState)(2);
	const [sl, setSl] = (0, import_react.useState)(3);
	const [batch, setBatch] = (0, import_react.useState)(0);
	const [location, setLocation] = (0, import_react.useState)("extreme");
	const [tags, setTags] = (0, import_react.useState)(["fib75", "with-trend"]);
	const board = (0, import_react.useMemo)(() => scanBoard(), []);
	const live = board.filter((p) => p.verdict.book === "ACTIONABLE");
	const liveWatch = board.filter((p) => p.verdict.book === "WATCH");
	const liveReject = board.filter((p) => p.verdict.book === "REJECT");
	const verdict = decide({
		symbol,
		side,
		tags,
		btcBias,
		confirm,
		tpAlreadyTraded: stale,
		mode,
		distPct: dist,
		rr,
		slPct: sl,
		location,
		sameDirectionToday: batch
	});
	function toggle(tag) {
		setTags((cur) => cur.includes(tag) ? cur.filter((t) => t !== tag) : [...cur, tag]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-6 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "num text-xs tracking-widest text-primary",
						children: ["MESIN · ", RULES.version]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-tight",
						children: "Analisis LONG dan SHORT"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-xl text-sm text-muted",
						children: "Kedua arah diterbitkan hanya di ekstrem, searah bias BTC, dan dengan konfluensi. Monday Low polos, Wolf polos, dan setup yang TP-nya sudah kena tidak masuk."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "num text-xs text-muted",
					children: "Legacy 14 TP / 47 SL · −0,31 R"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 rounded-xl border border-danger/40 bg-surface px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-danger",
					children: "Belum ada edge. Jangan pakai uang real."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-muted",
					children: "Angka “setelah gerbang” adalah saringan pada trade yang sama (in-sample). Itu menunjukkan kebocoran yang terpotong, bukan bukti strategi baru. Forward test baru mulai dari nol: 150 trade terisi dan 20 minggu, CI expectancy bersih di atas nol."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Papan keputusan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							live.length,
							" siap · ",
							liveWatch.length,
							" watch · ",
							liveReject.length,
							" ditolak"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: board.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-border bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "num text-lg",
									children: p.symbol
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `text-sm font-medium ${p.side === "LONG" ? "text-primary" : "text-danger"}`,
									children: p.side
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `num text-xs ${p.verdict.book === "ACTIONABLE" ? "text-primary" : p.verdict.book === "WATCH" ? "text-warn" : "text-danger"}`,
									children: p.verdict.book
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "num mt-2 text-xs text-muted",
								children: [
									p.mode,
									" · entry ",
									p.entry,
									" · SL ",
									p.sl,
									" · TP ",
									p.tp
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: p.verdict.note
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted",
								children: p.tags.map(tagLabel).join(" · ")
							})
						]
					}, p.symbol))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-6 grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Legacy terisi",
						v: "23,0%",
						s: "61 trade · −19 R"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Buku skor v2",
						v: pct(kept.winRate),
						s: `${kept.n} trade · ${rtxt(kept.totalR)} · ${rtxt(kept.expectancy)}`,
						hot: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Tidak diskor",
						v: `${rejected.n + watch.n}`,
						s: `Tolak ${rejected.n} · Watch ${watch.n} · ${rtxt(rejected.totalR + watch.totalR)} di luar buku`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-6 grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-surface p-4 lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-sm font-medium",
							children: "R harian legacy, Oktober"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-48",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
									data: DAILY,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "day",
											tick: {
												fill: "var(--color-muted)",
												fontSize: 12
											},
											axisLine: false,
											tickLine: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											tick: {
												fill: "var(--color-muted)",
												fontSize: 12
											},
											axisLine: false,
											tickLine: false,
											width: 32
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
											cursor: { fill: "var(--color-surface-2)" },
											contentStyle: {
												background: "var(--color-surface)",
												border: "1px solid var(--color-border)",
												borderRadius: 8
											},
											labelFormatter: (d) => `Okt ${d}`
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: "r",
											radius: [
												4,
												4,
												0,
												0
											],
											children: DAILY.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: d.r >= 0 ? "var(--color-primary)" : "var(--color-danger)" }, d.day))
										})
									]
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: "19 Okt tidak separah Mesin 1, tapi 15 Okt −13 R: satu hari, banyak SHORT/LONG yang bergerak bareng."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-2 rounded-xl border border-border bg-surface p-4 text-sm lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "font-medium",
							children: "Yang berubah"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-muted",
							children: "LONG dan SHORT sama-sama boleh. LONG mati hanya jika BTC turun; SHORT mati hanya jika BTC naik."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-muted",
							children: "Monday Low tanpa dua struktur lain tetap mati. Itu sumber −28 R, bukan arah LONG-nya."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-muted",
							children: "Tengah range = Watch. Satu pemicu tanpa tren atau divergensi = Watch."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-muted",
							children: [
								"Maks ",
								RULES.maxSameDirection,
								" setup searah per hari. TP yang sudah kena sebelum keputusan ditolak, bukan dilabel EXPIRED."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-muted",
							children: [
								"EXPIRED legacy ",
								LEGACY.expired,
								" dan pending ",
								LEGACY.pending,
								" tidak masuk win rate, sama seperti monitor."
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-3 flex gap-2 overflow-x-auto",
					children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(t.id),
						className: `shrink-0 rounded-full px-4 py-2 text-sm ${tab === t.id ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`,
						children: t.label
					}, t.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto rounded-xl border border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[640px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-surface-2 text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "Alasan"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "Arah"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "n"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "Win"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "Total R"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "v2"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: visible.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: r.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "num px-3 py-2",
									children: r.side
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "num px-3 py-2",
									children: r.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "num px-3 py-2",
									children: r.n ? `${Math.round(r.wins / r.n * 100)}%` : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `num px-3 py-2 ${r.totalR < 0 ? "text-danger" : "text-primary"}`,
									children: rtxt(r.totalR)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "num text-xs",
										children: r.code
									})
								})
							]
						}, r.id)) })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "rounded-xl border border-border bg-surface p-4",
					onSubmit: (e) => e.preventDefault(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 text-sm font-medium",
							children: "Uji gerbang pada setup baru"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mb-3 block text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Simbol"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: symbol,
								onChange: (e) => setSymbol(e.target.value),
								className: "mt-1 w-full rounded-lg border border-border bg-bg px-3 py-2"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 grid grid-cols-2 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
									label: "Arah",
									value: side,
									onChange: (v) => setSide(v),
									options: ["SHORT", "LONG"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
									label: "Bias BTC",
									value: String(btcBias),
									onChange: (v) => setBtcBias(Number(v)),
									options: [
										"-1",
										"0",
										"1"
									],
									labels: [
										"Turun",
										"Datar",
										"Naik"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
									label: "Konfirmasi",
									value: confirm,
									onChange: (v) => setConfirm(v),
									options: [
										"ok",
										"wait",
										"bad"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
									label: "Mode",
									value: mode,
									onChange: (v) => setMode(v),
									options: ["limit", "market"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
									label: "Posisi di range",
									value: location,
									onChange: (v) => setLocation(v),
									options: ["extreme", "mid"],
									labels: ["Ekstrem", "Tengah"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: `Jarak entry ${dist.toFixed(2)}%`,
							min: 0,
							max: 6,
							step: .05,
							value: dist,
							onChange: setDist
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: `RR rencana ${rr.toFixed(1)}`,
							min: .5,
							max: 4,
							step: .1,
							value: rr,
							onChange: setRr
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: `SL ${sl.toFixed(1)}%`,
							min: .2,
							max: 20,
							step: .1,
							value: sl,
							onChange: setSl
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: `SHORT lain hari ini: ${batch}`,
							min: 0,
							max: 8,
							step: 1,
							value: batch,
							onChange: setBatch
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-2 flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: stale,
								onChange: (e) => setStale(e.target.checked)
							}), "TP sudah kena sebelum waktu keputusan"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: TAGS.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggle(tag),
								className: `rounded-full px-3 py-1.5 text-xs ${tags.includes(tag) ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`,
								children: tagLabel(tag)
							}, tag))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Keputusan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-1 text-xl font-semibold ${verdict.book === "ACTIONABLE" ? "text-primary" : verdict.book === "WATCH" ? "text-warn" : "text-danger"}`,
							children: verdict.book
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "num mt-1 text-sm",
							children: verdict.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: verdict.note
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-xs text-muted",
							children: "Kartu hanya boleh menulis Entry limit bila mode limit. Market menghitung ulang TP dari harga keputusan — TP lama yang sudah tembus tidak dibawa."
						})
					]
				})]
			})
		]
	});
}
function Stat({ k, v, s, hot }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl border p-4 ${hot ? "border-primary bg-surface" : "border-border bg-surface"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: k
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "num mt-1 text-2xl",
				children: v
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: s
			})
		]
	});
}
function Select({ label, value, onChange, options, labels }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			value,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1 w-full rounded-lg border border-border bg-bg px-3 py-2",
			children: options.map((o, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: o,
				children: labels?.[i] ?? o
			}, o))
		})]
	});
}
function Slider({ label, min, max, step, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mb-2 block text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "mt-1 w-full accent-primary",
			type: "range",
			min,
			max,
			step,
			value,
			onChange: (e) => onChange(Number(e.target.value))
		})]
	});
}
var SplitComponent = Desk;
//#endregion
export { SplitComponent as component };
