# PROMPT — Bangun ulang mesin analisis crypto (siap tempel ke Claude)

Salin seluruh isi di bawah garis ke Claude (Claude Code / Claude Opus). Lampirkan ketiga arsip, atau clone ketiga repo, ke workspace yang sama sebelum menjalankan prompt.

Arsip / repo sumber (jangan dianggap benar hanya karena sudah live):

- Mesin 1: `mesin1_crypto.zip` → repo `triasnugra/crypto` → https://triasnugra.github.io/crypto
- Mesin 2: `mesin2_tn.zip` → repo `triasnugra/tn` → https://triasnugra.github.io/tn
- Monitor: `terminal_monitor.zip` → repo `triasnugra/monitor` → https://triasnugra.github.io/monitor/

Data mesin 1 dan mesin 2 yang masuk ke monitor **sudah match**. Jangan buang waktu mencocokkan ulang selector. Perbaiki mesinnya.

---

## Peran

Kamu adalah engineer yang membangun **satu sistem analisis trading crypto baru**, siap di-push ke GitHub dan di-deploy lewat GitHub Actions + GitHub Pages. Bukan sketsa, bukan pseudo-code: **repo lengkap, tes lulus, workflow hijau secara lokal** (`npm test` tanpa jaringan).

Sistem ini mesin **riset dan forward-test kertas**. Bukan bot yang mengirim order. Tidak ada API key, tidak ada penempatan order, tidak ada ajakan memakai uang real.

Bahasa UI dan dokumen operator: **Bahasa Indonesia**. Identifier kode, status, dan field JSON: **Inggris**.

## Fakta yang sudah dikunci (jangan dibantah, jangan “diperbaiki” sembarangan)

Sumber angka: `monitor/site/data/dashboard.json`, `generatedAtWib` 2026-10-27 07:58, lingkup `independent`.

| Mesin | Terbit | TP | SL | EXPIRED | INVALID | PENDING | Win rate terisi | Expectancy |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Mesin 1 `crypto` | 249 | 5 | 84 | 87 | 33 | 40 | **5,6% (disebut 6,2%)** | **−0,70 R** (total −62,7 R) |
| Mesin 2 `tn` | 228 | 14 | 47 | 125 | 0 | 42 | **23,0%** | **−0,31 R** (total −19,0 R) |

Win rate di monitor **sudah** `TP / (TP+SL)` saja (`src/statistics/stats.js`). EXPIRED dan INVALID **tidak** masuk penyebut. Jadi 6,2% dan 23% adalah hasil trade yang **memang terisi**. Mengelompokkan ulang EXPIRED tidak otomatis membuat mesin layak ditradingkan. Expectancy terisi sudah negatif. Itu kegagalan strategi, bukan hanya bug label.

Pemilik sudah cek manual di TradingView:

- Tab **TP**: benar.
- Tab **SL**: benar.
- Logika sentuh TP setelah entry, dan sentuh SL setelah entry, **dipertahankan**. Bekukan dengan fixture. Jangan diubah supaya win rate kelihatan lebih bagus.

Tab **EXPIRED** salah. Gejala yang dilihat pemilik: **harga entry dan tanggal entry berada sesudah harga TP, dan TP itu sudah tercetak 2–3 hari sebelumnya.** Itu bukan “limit tidak kesentuh”. Itu setup terlambat / basi yang diterbitkan setelah targetnya sudah terjadi, lalu dievaluasi seolah-olah itu kedaluwarsa yang sah.

Tab **INVALID** keterangannya:

1. `Setup sudah ada sebelum pelacakan dimulai; waktu analisis tidak diketahui, jadi tidak dievaluasi.` (`ANALYSIS_TIME_UNKNOWN`)
2. `symbol kosong` (`MISSING_SYMBOL`)

Kedua alasan itu adalah cacat produk, bukan hasil trading.

## Akar penyebab yang wajib kamu hapus (sudah ada di kode, jangan mencari ulang dari nol)

1. **Entry dikejar, TP lama dibiarkan.**
   - Mesin 1 `engine.mjs` `mkPlan`: `entry = side==1 ? min(level, px) : max(level, px)` lalu TP tetap tepi range / target struktur yang bisa sudah tertembus.
   - Mesin 2 `core.mjs` `feat`: baris yang sama (`entry = side==1 ? min(lvl, px) : max(lvl, px)`), TP = `entry + side*2*risk` atau tepi range `t2`.
   - Kalau harga sudah lewat level menuju TP, ini bukan limit retest. Ini setup yang lahir terlambat. Kartu Mesin 1 masih bisa bertuliskan **"Entry limit"** padahal `mode` sebenarnya `pasar` (diakui di `docs/JOURNAL.md`). Label bohong ini dihapus.

2. **Evaluator mengunci keterlambatan itu sebagai EXPIRED.**
   - `monitor/src/evaluator/evaluate.js` fungsi `step`, fase `waiting`: jika candle menyentuh TP sebelum entry tersentuh → `EXPIRED` / `TP_REACHED_BEFORE_ENTRY`.
   - Aturan “TP sebelum entry bukan menang” **tetap benar**. Yang salah: bucket-nya dicampur dengan limit yang benar-benar tidak pernah kesentuh, dan setup seperti ini tetap **diterbitkan**.
   - Jam analisis Mesin 1 dari scraper DOM sering `first_seen` (scan), bukan jam keputusan. Kartu DOM **tidak punya waktu analisis** (`docs/VERIFIED.md`). Setup yang sudah ada saat pelacakan mulai jadi `unknown_before_tracking` → INVALID. Itu sebab baris (a).

3. **Symbol kosong tetap masuk catatan**, baru ditolak di evaluator (`MISSING_SYMBOL`). Baris (b). Mesin baru menolaknya **sebelum** jurnal.

4. **Dua simulator berbeda.** Monitor: TTL entry 72 jam, hold maks 30 hari, tanpa fee. Mesin 2: `due` 7 hari, fee 0,05% per sisi + slippage 0,05% (`forward-lib.mjs`). Perbedaan ini tidak boleh lagi tersembunyi.

5. **Batch satu arah = satu taruhan, dihitung seperti banyak trade.** Contoh protokol: 20 setup LONG Mesin 2 pada 14 Okt 2026 hampir seluruhnya satu penurunan pasar. Statistik yang menghitung itu sebagai 20 observasi independen adalah menyesatkan. Penerbit juga tidak boleh membanjiri 20 sinyal searah pada hari yang sama.

6. **Look-ahead.** Mesin 2 sudah benar di `scanInput`: keputusan dari **open hari ini saja** (high=low=close=open, volume 0), candle hari ini yang belum tutup tidak dilihat. Mesin 1 belum seketat itu (memakai close candle berjalan). Standar baru = standar `scanInput`, untuk semua strategi dan semua timeframe: **hanya candle yang sudah tutup pada waktu keputusan.**

## Yang dipertahankan (fungsi yang bagus, bukan teks UI-nya)

Dari Mesin 1:

- Fungsi murni analisis: struktur 4H + 1D, pivot, Monday sweep (jendela 12 candle 4H), level mingguan, bias harian, peringatan FOMC / libur / Senin / tutup minggu / tutup bulan.
- SL di luar struktur, jarak minimum `max(1% harga, 0,8 ATR)`, bukan di dalam noise. Setup `confirm === bad` (close 12H menembus SL) tidak diterbitkan.
- Beberapa target (TP1/TP2/TP3), tetapi **nilai resmi forward-test = TP1** (yang sudah dicek pemilik). TP2+ hanya kolom tambahan, tidak dicampur ke win rate.
- Desain jurnal di `docs/JOURNAL.md`: append-only, rantai hash, level membeku pada kemunculan pertama, revisi dicatat tidak menimpa, gagal scan (BTC gagal atau >25% koin gagal) **tidak** menulis jurnal setengah, hash mesin = hash file strategi.
- Replay tanpa look-ahead (`validate.mjs` `at()`): candle berjalan disusun dari candle lebih kecil sampai timestamp keputusan.
- Fetch Binance multi-host + timeout. Universe dicatat **pada saat keputusan**, bukan “top 40 hari ini” yang dipakai untuk menilai masa lalu (survivorship).

Dari Mesin 2:

- `scanInput` sebagai satu-satunya pintu data (anti look-ahead, anti beda hasil gara-gara jam scan).
- `trade-sim` yang **sama** untuk backtest, jurnal live, dan monitor. Candle ambigu: SL didahulukan bila tidak ada data 1 menit; bila ada 1 menit, urutan sentuhan yang menang, tidak menebak.
- Protokol forward tersegel (`forward-protocol.json` tidak ditimpa), rantai hash, baseline **MARKET** (arah sama, entry di open) dan **MIRROR** (arah dibalik) pada sinyal yang sama.
- Biaya: fee 0,05% per sisi + slippage 0,05% pada trade terisi saja. Tidak terisi = biaya 0.
- Riset varian terkunci (`scripts/research.mjs`): pilih aturan hanya dari data sebelum tanggal pisah, uji **sekali** sesudahnya. Jangan menambah varian setelah melihat hasil uji.
- Tipe `ditolak` bila SL terlalu lebar atau RR tidak layak. Penolakan ini tidak masuk win rate.

Dari monitor:

- Status akhir tidak boleh ditebak. Data 1 menit hilang atau TP+SL satu candle tanpa urutan → `AMBIGUOUS`, bukan TP.
- Upsert idempoten, `audit.jsonl`, raw snapshot, panel selisih hasil sumber vs evaluator.
- Klaster near-duplicate: mesin + simbol + arah, jendela 24 jam, entry ±1%. Satu klaster = satu observasi untuk kesimpulan.
- Bootstrap CI. Verdict “mesin A lebih baik” hanya jika syarat sampel terpenuhi **dan** CI95 selisih expectancy tidak memuat 0.
- Klines `data-api.binance.vision` dengan fallback. Simbol tidak dikenal → ditolak, bukan dianalisis.
- Discover ber-timeout (insiden job 15 menit yang menggantung di Playwright). Jalur scan produksi **tidak memakai Playwright**. DOM hanya uji kesetiaan opsional.
- Halaman statis GitHub Pages, tanpa secret.

## Yang dihilangkan

- DOM sebagai sumber kebenaran Mesin 1.
- Setup yang TP-nya sudah tercetak sebelum waktu keputusan.
- Menyebut market sebagai “Entry limit”.
- Menghitung setup basi sebagai EXPIRED.
- Baris jurnal tanpa simbol, tanpa waktu keputusan, atau dengan level yang tidak konsisten dengan arah.
- Dua aturan evaluasi yang berbeda untuk dua mesin.
- Panel win rate berjalan yang terlihat seperti izin trading (sudah dilarang di `FORWARD.md`; panel lama diabaikan).
- Menghapus, menimpa, atau menghitung ulang rantai hash baris yang rugi. Arsip lama dibekukan read-only.
- Menggabungkan expectancy versi mesin yang hash-nya berbeda.
- Order live, leverage, saldo, API key exchange.
- Janji win rate naik. Kode yang melonggarkan gerbang supaya angka hijau ditolak.

## Repo yang harus kamu hasilkan

Satu monorepo baru (nama paket `mesin-crypto`, folder root repo). Tiga situs lama **tidak** diubah di tempat dan protokol forward lama **tidak** dilanjutkan dengan hash baru diam-diam. Mesin ini protokol baru. Jurnal lama boleh diimpor sebagai arsip `legacy` dan **keluar** dari klaim edge.

```
packages/market/        klien Binance, jam candle tutup, pemetaan simbol USDT
packages/sim/           SATU simulator (fill, TP, SL, bucket hasil, biaya, 1m)
packages/journal/       rantai hash, merge, verify, tolak tulis bila rusak
packages/gate/          gerbang terbit (basi, simbol, RR, rezim, korelasi)
packages/strategies/
  m1-structure/         port strategi Mesin 1, versi 2.0.0, fungsi murni
  m2-eliz/              port strategi Mesin 2, versi 2.0.0, fungsi murni
apps/web/               satu situs statis: dashboard + kartu kedua strategi
scripts/                scan, evaluate, backtest, research, forward report
test/                   unit tanpa jaringan + fixture bug EXPIRED
.github/workflows/      ci, scan, pages
docs/                   DIAGNOSIS, HYPOTHESES, PROTOCOL, CARA-DEPLOY
```

Node `>=20`, ESM, tanpa bundler wajib. Halaman membaca JSON yang sudah di-generate. Dependensi hanya yang benar-benar perlu. Tidak ada Playwright di jalur scan.

Kode strategi lama satu-huruf (`engine.mjs`, `core.mjs`) **di-port ke nama yang bisa dibaca**, dengan tes yang mengunci perilaku yang memang dipertahankan. Jangan menyalin minifikasi.

## Gerbang terbit (hard reject — setup tidak masuk jurnal skor)

Semua ini diuji otomatis. Urutan:

1. Simbol kosong, bukan `[A-Z0-9]{2,20}`, atau tidak ada pasangan `SIMBOLUSDT` di Binance → buang + baris audit. **Tidak ada** status INVALID “symbol kosong” di jurnal baru.
2. Waktu keputusan = waktu tutup candle terakhir yang dipakai. Tidak ada. Tidak ada baris “waktu analisis tidak diketahui” di jurnal baru. (Arsip legacy tetap menyimpan 33 INVALID lama sebagai `LEGACY_UNKNOWN_TIME`, tidak dievaluasi, tidak masuk win rate.)
3. **Uji look-ahead:** memberi candle masa depan yang mengubah high/low setelah waktu keputusan tidak boleh mengubah sinyal. Tes ini wajib gagal membangun jika dilanggar.
4. **Uji basi (bug EXPIRED pemilik):** pada waktu keputusan, telusuri candle dari peristiwa struktur sampai keputusan.
   - Jika high (long) atau low (short) sudah menyentuh TP1 **kapan pun sebelum waktu keputusan**, termasuk pola yang pemilik lihat (TP tercetak **2 atau 3 hari sebelum** tanggal entry) → tolak dengan alasan `STALE_TP_ALREADY_TRADED`.
   - Jangan simpan lalu label EXPIRED.
   - Fixture wajib: entry timestamp > waktu sentuh TP sekitar 2 hari dan 3 hari → tidak terbit, dan jika evaluator dipaksa menerima record itu hasilnya **bukan** `EXPIRED`.
5. Limit hanya jika jarak harga keputusan ke entry di dalam pita yang ditulis di hipotesis (awal: 0,15%–2,5%) **dan** entry masih di sisi yang belum dibayar TP.
   - Harga sudah lewat level menuju target → **jangan** `min(level, harga)` dengan TP lama.
   - Pilihan yang sah hanya: (A) buang karena terlewat, atau (B) entry market **eksplisit** pada harga keputusan, SL/TP **dihitung ulang dari harga itu**, RR setelah biaya masih ≥ minimum, dan TP baru belum tersentuh. Label kartu = `market`, bukan `Entry limit`.
6. RR rencana ke TP1 setelah biaya ≥ 1,5. Di bawah itu → `ditolak`, tidak diterbitkan.
7. Jarak SL ≥ `max(0,8 ATR, 0,6%)` dan ≤ batas yang ditulis di hipotesis (awal 8% untuk buku utama). SL 15–30% “spot lebar” tidak masuk buku utama.
8. `confirm === bad` tidak terbit. `confirm === wait` hanya status **WATCH**, bukan setup yang bisa terisi. Hanya `ok` yang masuk jurnal skor.
9. Paling banyak **satu** ide aktif per simbol per strategi.
10. Paling banyak **3** setup baru searah per strategi per hari UTC (bukan 20 LONG satu hari). Selebihnya ditolak `CORRELATION_CAP` dan dicatat di audit. Angka 3 ada di config, disebut di hipotesis, tidak dinaikkan setelah melihat hasil.
11. Jika bias harian koin **dan** bias BTC berlawanan dengan arah, setup tidak masuk buku utama (boleh tag terpisah `countertrend` yang **tidak** dicampur ke expectancy utama). Peringatan FOMC yang dulu hanya teks kini jadi aturan: hari FOMC dan hari berikutnya tidak membuka setup baru.
12. Level wajib konsisten: LONG `SL < entry < TP1`, SHORT `TP1 < entry < SL`. Jika tidak → tolak `LEVELS_INCONSISTENT`, jangan INVALID di hilir.

## Simulator tunggal (pakai untuk backtest, live, dashboard)

Hasil yang boleh muncul:

| Status | Arti | Masuk win rate? | Masuk expectancy? |
|---|---|---|---|
| `PENDING` | belum ada hasil | tidak | tidak |
| `WATCH` | belum konfirmasi | tidak | tidak |
| `TP` | entry terisi dulu, TP1 tersentuh kemudian | ya (menang) | ya |
| `SL` | entry terisi dulu, SL tersentuh kemudian | ya (kalah) | ya |
| `UNFILLED` | TTL habis, entry tidak tersentuh, **dan** TP tidak tersentuh sebelum fill | tidak | tidak (tampil terpisah) |
| `MISSED_TP_BEFORE_FILL` | setelah terbit, TP tersentuh sebelum entry | tidak | tidak |
| `STALE_AT_PUBLISH` | TP sudah tersentuh sebelum waktu keputusan (seharusnya tidak lolos gerbang; ini jaring pengaman) | tidak | tidak |
| `CANCELLED` | close menembus SL / struktur batal sebelum fill | tidak | tidak |
| `AMBIGUOUS` | urutan dalam satu candle tidak bisa dipastikan | tidak | tidak |
| `LEGACY_*` | arsip lama (waktu tidak diketahui, simbol kosong, EXPIRED lama yang belum diklasifikasi ulang) | tidak | tidak |

Jangan pakai lagi satu kata `EXPIRED` untuk semua “tidak menang”. Tab UI:

- Actionable, Watch, Open, TP, SL, Unfilled, Missed (TP sebelum entry), Cancelled, Ambiguous, Legacy.

Aturan yang sudah benar dan wajib tetap:

- TP setelah fill = TP. SL setelah fill = SL. Sama dengan cek TradingView pemilik.
- TP dan SL di candle yang sama → turun ke 1 menit. Tanpa 1 menit → `AMBIGUOUS`. Jangan menghadiahkan TP.
- Isi limit saat harga menyentuh level. Market terisi di harga keputusan yang sudah didefinisikan (tulis satu definisi, pakai di semua jalur: **close candle keputusan**).
- TTL entry default **7 hari** (samakan dengan `due` Mesin 2, bukan 72 jam diam-diam). Hold maksimum setelah fill **7 hari**, kecuali hipotesis menulis lain **sebelum** protokol disegel. Satu config, tiga pemakai.
- R resmi: menang = `|TP1−fill| / |fill−SL|` lalu **dikurangi biaya dalam R** (biaya% / risiko%). Kalah = `−1` dikurangi biaya dalam R. Hanya TP1.
- Primary metric = **expectancy R bersih**. Win rate sekunder = `TP/(TP+SL)` pada trade terisi saja. Tampilkan juga “berapa % terbitan yang terisi” supaya EXPIRED lama tidak disalahbaca.

## Protokol statistik (salin ketat, jangan dilunakkan)

Tulis `docs/PROTOCOL.md` dan bekukan di `data/forward-protocol.json` pada run pertama (file tidak ditimpa).

- Unit independensi = **minggu kalender ISO UTC**, bukan jumlah trade. Bootstrap mengacak minggu.
- Biaya = 0,05% fee per sisi + 0,05% slippage pada trade terisi.
- **Jangan** menyatakan “punya edge” sebelum: ≥ **150 trade terisi** dan ≥ **20 minggu** independen, dan batas bawah CI95 expectancy bersih (bootstrap per minggu) **> 0**.
- Di bawah itu dashboard menulis persis: **BELUM ADA EDGE. JANGAN PAKAI UANG REAL.** Angka kinerja boleh terlihat hanya di balik tombol “intip” bertanda **TIDAK SAH**, atau ditampilkan bersama banner itu. Jangan disembunyikan seolah hasilnya bagus, jangan juga disajikan sebagai sinyal beli.
- Tampilkan warisan sebagai fakta historis, bukan marketing: Mesin 1 lama 5 TP / 84 SL (≈6,2%, −0,70 R), Mesin 2 lama 14 TP / 47 SL (≈23%, −0,31 R), per 27 Okt 2026. Sistem baru **belum** mewarisi angka itu sebagai prestasi.
- Ganti parameter strategi = versi baru = hash baru = protokol baru mulai dari nol. Dilarang menyetel filter setelah melihat kohort yang sedang berjalan.
- Baseline MARKET dan MIRROR wajib di laporan. Strategi yang kalah dari keduanya tidak disebut berguna.
- Backtest: universe dan biaya sama dengan live. Sebut survivorship bila universe = top volume hari ini. Tanggal pisah riset dikunci di file (pakai `2025-07-01` seperti riset Mesin 2 kecuali kamu tulis alasan sebelum menjalankan). Jangan ganti tanggal setelah melihat hasil.
- Hipotesis tiap filter baru ditulis di `docs/HYPOTHESES.md` **sebelum** angka out-of-sample. Isi awal yang wajib ada (boleh kamu pertajam, tidak boleh kamu hapus):
  - menolak setup yang TP-nya sudah kena sebelum keputusan akan memindahkan kasus “entry sesudah TP 2–3 hari” dari EXPIRED ke penolakan, dan tidak menaikkan win rate terisi dengan sendirinya;
  - mengganti `min(level, harga)` + TP lama dengan “buang atau market dengan TP baru” mengurangi SL yang terjadi karena mengejar;
  - tutup korelasi 3/hari mengurangi kerugian batch satu arah;
  - tidak ada hipotesis “win rate akan di atas 50%”.

`docs/DIAGNOSIS.md` ditulis **pertama**, dari data monitor + jurnal yang ada di zip, sebelum mengubah rumus strategi:

- pecah 87 EXPIRED Mesin 1 dan 125 EXPIRED Mesin 2 menjadi: TP sudah kena sebelum timestamp entry/analisis (termasuk jarak 2–3 hari), versus limit benar-benar tidak kesentuh dan TP tidak kena;
- hitung expectancy terisi saat ini (sudah negatif) supaya tidak ada ilusi bahwa relabel saja cukup;
- daftar berapa baris INVALID karena waktu tidak diketahui vs simbol kosong.

## UI

Satu halaman dashboard, gelap, padat, bisa dibaca di laptop, bukan landing page marketing.

Wajib tampil:

- Banner merah tetap selama gerbang 150/20 belum terpenuhi.
- Dua strategi (M1 struktur, M2 Eliz) sebagai versi bernomor + 12 karakter hash, bukan “mesin ajaib”.
- Tab status di atas. Baris: simbol, arah, waktu keputusan UTC, mode `limit|market`, entry, SL, TP1, RR rencana, hasil, waktu hasil, alasan singkat, versi.
- Kartu publik tidak menulis “Entry limit” kecuali mode benar-benar limit.
- Blok mutu data: jumlah simbol kosong jurnal baru harus 0; jumlah tolakan `STALE_TP_ALREADY_TRADED` hari ini; selisih grade ulang vs grade tersimpan.
- Kurva ekuitas dalam R, drawdown R, CI, profit factor, rata menang/kalah, per versi. Legacy dipisah.
- Teks footer: hasil teoretis candle Binance, bukan eksekusi nyata, bukan saran finansial.

Jangan tampilkan win rate besar tanpa expectancy dan tanpa ukuran sampel di sampingnya.

## GitHub Actions

Tiga workflow:

1. `ci.yml` pada push dan PR: `npm test`. Tanpa jaringan. Wajib merah jika fixture basi, look-ahead, hash, atau label market gagal.
2. `scan.yml` cron tiap 4 jam + `workflow_dispatch`:
   - ambil klines, jalankan kedua strategi lewat gerbang, append jurnal, verifikasi rantai;
   - BTC gagal atau >25% simbol gagal atau rantai rusak → job merah, `journal.json` tidak berubah;
   - lalu grade posisi terbuka dan tulis `apps/web/data/*.json`;
   - concurrency satu, supaya dua scan tidak bentrok.
3. `pages.yml`: GitHub Pages dari artefak statis `apps/web`.

Izin: contents write, pages write. Tanpa secret. README bagian deploy, langkahnya persis:

1. Buat repo kosong, push isi monorepo.
2. Settings → Pages → Source: GitHub Actions.
3. Settings → Actions → Workflow permissions: Read and write.
4. Actions → scan → Run workflow.
5. Tunggu deployment Pages. Dashboard di `https://<user>.github.io/<repo>/`.

Sertakan `.gitignore` yang tidak mengabaikan `data/journal.json` (jurnal harus di-commit bot). Abaikan cache klines backtest.

## Tes yang wajib ada dan lulus

- Candle masa depan tidak mengubah sinyal.
- TP sudah kena 2 hari sebelum entry → tidak terbit; evaluator paksa → bukan `EXPIRED`.
- Sama untuk 3 hari.
- Limit tidak tersentuh, TP tidak tersentuh, TTL lewat → `UNFILLED`.
- Long TP setelah fill, dan short TP setelah fill, pada fixture beku → `TP` (pertahankan kebenaran TradingView).
- Long SL dan short SL setelah fill → `SL`.
- TP+SL satu candle 15m tanpa 1m → `AMBIGUOUS`; dengan 1m → status sentuhan pertama.
- Simbol `""` ditolak gerbang, tidak ada di jurnal.
- Mutasi `entry` pada baris lama terdeteksi rantai hash. Generator menolak append ke jurnal rusak.
- Scan gagal tidak mengubah byte `journal.json`.
- Sinyal market tidak pernah berlabel “Entry limit”.
- `winRate` tidak berubah ketika baris UNFILLED / STALE / LEGACY ditambah.
- Biaya membuat R menang lebih kecil dari R kotor.
- Dua puluh sinyal LONG satu hari: hanya 3 yang masuk jurnal skor.
- `scanInput`: high/low hari berjalan tidak terlihat oleh strategi harian.

## Urutan kerja

1. Baca ketiga kode. Tulis `docs/DIAGNOSIS.md` dengan hitungan, bukan kesan.
2. Tulis `docs/HYPOTHESES.md` dan `docs/PROTOCOL.md`.
3. Implement `packages/sim` + tes TP/SL dulu (perilaku lama yang benar).
4. Implement gerbang + tes basi 2–3 hari.
5. Port M1 dan M2 ke fungsi murni di atas jam candle tutup. Hapus pola `min(level, px)` yang mempertahankan TP lama.
6. Jurnal, scan, dashboard, workflow.
7. `npm test` hijau. Jalankan backtest hanya jika jaringan ke Binance ada; jika tidak, tulis di README bahwa backtest belum dijalankan di lingkungan build dan **jangan mengarang angka**.
8. Jangan longgarkan tes untuk membuat CI hijau.

## Definisi selesai

- Repo lengkap, bukan cuplikan.
- `npm test` lulus.
- README deploy Pages benar.
- Tidak ada jalur yang menerbitkan setup dengan TP sudah kena sebelum waktu keputusan.
- Tidak ada jurnal baru tanpa simbol atau tanpa waktu keputusan.
- TP/SL yang sudah benar tidak berubah makna.
- Dashboard menolak kesan bahwa 6,2% atau 23% sudah diperbaiki. Sampai gerbang 150 trade / 20 minggu dan CI, satu-satunya kalimat keputusan adalah: belum ada edge, jangan pakai uang real.

## Larangan

- Jangan menaikkan win rate dengan menghapus SL, memperlonggar TP, atau memasukkan UNFILLED sebagai menang.
- Jangan menghitung ulang hash arsip supaya sejarah rugi hilang.
- Jangan mencampur versi.
- Jangan menambahkan varian atau mengganti tanggal pisah setelah melihat hasil uji.
- Jangan membuat bot order.
- Jangan mengklaim mesin “profesional dan profitable”. Profesional di sini artinya jujur, dapat diaudit, dan tidak mempublikasikan setup yang sudah mati.
